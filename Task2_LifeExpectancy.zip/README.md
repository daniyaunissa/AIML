# 📊 Task 2: Linear Regression & K-Means Clustering

## Dataset
- File: `life_expectancy.csv`
- Source: Contains life expectancy data of 200 countries by gender.

## 🔹 Linear Regression
**Objective:** Predict the life expectancy for both sexes using male and female life expectancy.

- Input Features:
  - Sum of Females Life Expectancy
  - Sum of Males Life Expectancy
- Output Target:
  - Sum of Life Expectancy (both sexes)

## 🔹 K-Means Clustering
**Objective:** Group countries based on life expectancy similarity.

- Features Used:
  - Sum of Females Life Expectancy
  - Sum of Males Life Expectancy
- Model: `KMeans(n_clusters=3)`

## ▶️ How to Run
```bash
python linear_regression.py
python kmeans_clustering.py
```

Enjoy exploring life expectancy with ML! 🌍
