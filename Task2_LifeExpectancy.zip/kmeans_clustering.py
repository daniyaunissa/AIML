import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

# Load data
df = pd.read_csv("life_expectancy.csv")

# Select features
features = df[["Sum of Females  Life Expectancy", "Sum of Males  Life Expectancy"]]

# Normalize
scaler = StandardScaler()
scaled_features = scaler.fit_transform(features)

# KMeans
kmeans = KMeans(n_clusters=3, random_state=42)
clusters = kmeans.fit_predict(scaled_features)

# Add cluster to dataframe
df["Cluster"] = clusters

# Plot
plt.scatter(df["Sum of Females  Life Expectancy"], df["Sum of Males  Life Expectancy"], 
            c=df["Cluster"], cmap="Set1")
plt.xlabel("Females Life Expectancy")
plt.ylabel("Males Life Expectancy")
plt.title("K-Means Clustering of Countries by Life Expectancy")
plt.grid(True)
plt.show()
